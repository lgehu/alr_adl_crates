This program demonstrates basic use of the LIS3DSH accelerometer chip.
(The LIS3DSH is used on later versions of the STM32F4 Discovery boards,
designated by the number MB997C printed on the top of the board.)

The LEDs surrounding the accelerometer will come on and off as the board
is moved, reflecting the directions of the accelerations measured by the
device. As the board is moved off of level the LEDs will flash on and off
accordingly.
