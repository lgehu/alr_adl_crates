This program demonstrates the STM32 on-board random number generator
hardware. The function Random is called iteratively, indefinitely, and
the results are displayed. Some display hardware is therefore assumed
but the demo is otherwise independent of specific boards (as long as the
RNG hardware functionality is present).
