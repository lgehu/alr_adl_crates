# W25Q16 - 2Mbyte SPI flash memory

[Datasheet](https://www.winbond.com/hq/support/documentation/downloadV2022.jsp?xmlPath=/support/resources/.content/item/DA00-W25Q80-16-32.html)

There is an example in [examples/stm32f4xx_m/flash/](../../../../examples/stm32f4xx_m/flash/).
